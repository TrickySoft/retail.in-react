export function fetchCallLogin(callback, url, method, payload) {
  return new Promise(function (resolve, reject) {
    const options = {
      method,
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json'
      }
    };
    fetch(url, options)
      .then(res => {
        return res.json();
      })
      .then(res => {
        callback(res);
        resolve(res);
      })
      .catch(err => {
        callback(err);
        return err;
      })

  })
}

export function fetchCall(callback, url, method, payload) {
  let userId = sessionStorage.getItem('userId');
  return new Promise(function (resolve, reject) {
    const options = {
      method,
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
        'userId': userId
      }
    };
    fetch(url, options)
      .then(res => {
        return res.json();
      })
      .then(res => {
        callback(res);
        resolve(res);
      })
      .catch(err => {
        callback(err);
        return err;
      })
  })
}

