import React, { useEffect, useState } from "react";
import {
  editManagerDetails,
  updateManagerDetails,
  editSlotDetails,
  updateSlotDetails,
  editStoreDetails,
  updateStoreDetails,
  addSlotDetails,
  createSlotDetails,
  addPinCode,
  createPinCode,
} from "../api/details";
import PropTypes from "prop-types";
import Loader from "../../components/loader";
import Input from "../../components/input";
import Button from "../../components/button";
import Dropdown from "app/components/dropdown";
import "./editDetail.scss";
import { Analytics } from "../../helpers/analytics";

const EditDetails = ({
  editManagerId,
  editSlotId,
  isAddSlot,
  editStoreCode,
  onHandleUpdate,
  isAddPinCode,
}) => {
  const [managerDetails, setManagerDetails] = useState([]);
  const [slotDetails, setSlotDetails] = useState([]);
  const [storeDetails, setStoreDetails] = useState([]);
  const [deliveryPinCodes, setPinCodes] = useState([]);

  useEffect(() => {
    editData();
  }, []);

  const editData = () => {
    if (editManagerId) {
      editManagerDetails(
        (response) => {
          const { message, content } = response;
          if (message === "SUCCESS") {
            setManagerDetails(content);
          }
        },
        {
          id: editManagerId,
        }
      );
    } else if (editSlotId) {
      editSlotDetails(
        (response) => {
          const { message, content } = response;
          if (message === "SUCCESS") {
            setSlotDetails(content);
          }
        },
        {
          id: editSlotId,
        }
      );
    } else if (editStoreCode && !isAddSlot && !isAddPinCode) {
      editStoreDetails(
        (response) => {
          const { message, content } = response;
          if (message === "SUCCESS") {
            let data = content.filter((store) => store.name !== "open_time");
            let openTime = content.find((store) => store.name === "open_time");
            let index = data.findIndex((store) => store.name === "close_time");
            data.splice(index + 1, 0, openTime);
            setStoreDetails(data);
          }
        },
        {
          store_code: editStoreCode,
        }
      );
    } else if (isAddSlot) {
      addSlotDetails((response) => {
        const { message, content } = response;
        if (message === "SUCCESS") {
          setSlotDetails(content);
        }
      });
    } else if (isAddPinCode) {
      addPinCode((response) => {
        const { message, content } = response;
        if (message === "SUCCESS") {
          setPinCodes(content);
        }
      });
    }
  };

  const handleValueChange = (event) => {
    let val = event.target.value;
    if (editManagerId) {
      let data = managerDetails.map((detail) => {
        if (detail.id === event.target.id) {
          detail.value = val;
        }
        return detail;
      });
      setManagerDetails(data);
    } else if (editSlotId || isAddSlot) {
      let data = slotDetails.map((detail) => {
        if (detail.id === event.target.id) {
          detail.value = val;
        }
        return detail;
      });
      setSlotDetails(data);
    } else if (editStoreCode && !isAddSlot && !isAddPinCode) {
      let data = storeDetails.map((detail) => {
        if (detail.id === event.target.id) {
          detail.value = val;
        }
        return detail;
      });
      setStoreDetails(data);
    } else if (isAddPinCode) {
      let data = deliveryPinCodes.map((detail) => {
        if (detail.id === event.target.id) {
          detail.value = val;
        }
        return detail;
      });
      setPinCodes(data);
    }
  };

  const handleUpdate = (event) => {
    if (event.target.id === "updateManager") {
      let fName = "",
        lName = "",
        phNumber = "";
      managerDetails.map((detail) => {
        if (detail.name === "firstname") {
          fName = detail.value;
        } else if (detail.name === "lastname") {
          lName = detail.value;
        } else if (detail.name === "mobile") {
          phNumber = detail.value;
        }
      });
      let payload = {
        id: editManagerId,
        firstname: fName,
        lastname: lName,
        mobile: phNumber,
      };

      updateManagerDetails((response) => {
        debugger;
        const { message } = response;
        if (message === "SUCCESS") {
          Analytics.logEventWithVariable(
            Analytics.OnUpdateDetails.updateDetails,
            JSON.stringify({ storeManager_updated: payload })
          );
          alert("Store Manager Details Updated!");
          onHandleUpdate(event.target.id);
        } else {
          alert("Fields should not be empty!");
        }
      }, payload);
    } else if (
      event.target.id === "updateSlot" ||
      event.target.id === "addSlot"
    ) {
      let capacity = 0,
        endTime = "",
        startTime = "",
        day = 0;
      slotDetails.map((detail) => {
        if (detail.name === "capacity_in_slot") {
          capacity = detail.value;
        } else if (detail.name === "slot_end_time") {
          endTime = detail.value;
        } else if (detail.name === "slot_start_time") {
          startTime = detail.value;
        } else if (detail.name === "week_day") {
          day = detail.value ? detail.value : 0;
        }
      });
      if (!isAddSlot) {
        let payload = {
          id: editSlotId,
          capacity_in_slot: capacity,
          slot_end_time: endTime,
          slot_start_time: startTime,
          week_day: day,
        };

        updateSlotDetails((response) => {
          const { message } = response;
          if (message === "SUCCESS") {
            Analytics.logEventWithVariable(
              Analytics.OnUpdateDetails.updateDetails,
              JSON.stringify({ slot_updated: payload })
            );
            alert("Slot Updated!");
            onHandleUpdate(event.target.id);
          } else {
            alert("Fields should not be empty!");
          }
        }, payload);
      } else {
        let payload = {
          store_code: editStoreCode,
          capacity_in_slot: capacity,
          slot_end_time: endTime,
          slot_start_time: startTime,
          week_day: day,
        };
        createSlotDetails((response) => {
          const { message } = response;
          if (message === "SUCCESS") {
            Analytics.logEventWithVariable(
              Analytics.OnAddDetails.addDetails,
              JSON.stringify({ slot_added: payload })
            );
            alert("Slot Added!");
            onHandleUpdate(event.target.id);
          } else {
            alert("Fields should not be empty or slot already exists, Please add different slot!");
          }
        }, payload);
      }
    } else if (event.target.id === "updateStore") {
      let storeName = 0,
        coms = "",
        city = "",
        storeAddr = "",
        closeTime = "",
        openTime = "",
        contactNo = "",
        custName = "",
        dcCity = "",
        locality = "",
        terminals = 0,
        posTerminals = "",
        state = "",
        latStore = "",
        logStore = "",
        serviceStartTime = "",
        serviceEndTime = "",
        pincode = "",
        timeSlots = 0;
      storeDetails.map((detail) => {
        if (detail.name === "address_of_the_store") {
          storeAddr = detail.value;
        } else if (detail.name === "close_time") {
          closeTime = detail.value;
        } else if (detail.name === "contact_no") {
          contactNo = detail.value;
        } else if (detail.name === "customer_preferred_name") {
          custName = detail.value;
        } else if (detail.name === "dc_city") {
          dcCity = detail.value;
        } else if (detail.name === "locality") {
          locality = detail.value;
        } else if (detail.name === "no_of_terminals") {
          terminals = detail.value;
        } else if (detail.name === "pos_terminal") {
          posTerminals = detail.value;
        } else if (detail.name === "open_time") {
          openTime = detail.value;
        } else if (detail.name === "state") {
          state = detail.value;
        } else if (detail.name === "store_latitude") {
          latStore = detail.value;
        } else if (detail.name === "store_longitude") {
          logStore = detail.value;
        } else if (detail.name === "store_name") {
          storeName = detail.value;
        } else if (detail.name === "coms") {
          coms = detail.value;
        } else if (detail.name === "city") {
          city = detail.value;
        } else if (detail.name === "store_online_servicing_hours_end_time") {
          serviceStartTime = detail.value;
        } else if (detail.name === "store_online_servicing_hours_start_time") {
          serviceEndTime = detail.value;
        } else if (detail.name === "store_pin_code") {
          pincode = detail.value;
        } else if (detail.name === "time_slots") {
          timeSlots = detail.value;
        }
      });

      const regexp = /^[1-9]{1}[0-9]{2}[0-9]{3}$/;
      if (regexp.test(pincode)) {
        let payload = {
          store_code: editStoreCode,
          address_of_the_store: storeAddr,
          close_time: closeTime,
          contact_no: contactNo,
          customer_preferred_name: custName,
          dc_city: dcCity,
          locality: locality,
          no_of_terminals: terminals,
          open_time: openTime,
          pos_terminal: posTerminals,
          state: state,
          store_latitude: latStore,
          store_longitude: logStore,
          store_name: storeName,
          coms: coms,
          city: city,
          store_online_servicing_hours_end_time: serviceStartTime,
          store_online_servicing_hours_start_time: serviceEndTime,
          store_pin_code: pincode,
          time_slots: timeSlots,
        };

        updateStoreDetails((response) => {
          const { message } = response;
          if (message === "SUCCESS") {
            Analytics.logEventWithVariable(
              Analytics.OnUpdateDetails.updateDetails,
              JSON.stringify({ store_updated: payload })
            );
            alert("Store Details Updated!");
            onHandleUpdate(event.target.id);
          } else {
            alert("Fields should not be empty!");
          }
        }, payload);
      } else {
        alert("Please enter a valid PinCode!");
      }
    } else if (event.target.id === "addPincode") {
      let pincode = "";
      const regexp = /^[1-9]{1}[0-9]{2}[0-9]{3}$/;
      deliveryPinCodes.map((code) => {
        if (code.name === "delivery_pin_code") {
          pincode = code.value;
        }
      });
      if (regexp.test(pincode)) {
        let payload = {
          store_code: editStoreCode,
          delivery_pin_code: pincode,
        };
        createPinCode((response) => {
          const { message } = response;
          if (message === "SUCCESS") {
            Analytics.logEventWithVariable(
              Analytics.OnAddDetails.addDetails,
              JSON.stringify({
                store_code: editStoreCode,
                pincode_added: pincode,
              })
            );
            alert("PinCode Added!");
            onHandleUpdate(event.target.id);
          } else {
            alert("Pincode already exists please enter different Pincode!");
            let data = deliveryPinCodes.map((detail) => {
              if (detail.name === "delivery_pin_code") {
                detail.value = "";
              }
              return detail;
            });
            setPinCodes(data);
          }
        }, payload);
      } else {
        alert("Field should not be empty!");
        let data = deliveryPinCodes.map((detail) => {
          if (detail.name === "delivery_pin_code") {
            detail.value = "";
          }
          return detail;
        });
        setPinCodes(data);
      }
    }
  };

  const handleCancel = (event) => {
    onHandleUpdate(event.target.id);
  };

  return (
    <div>
      {editManagerId ? (
        managerDetails && managerDetails.length ? (
          <div>
            {managerDetails.map((detail, index) => {
              return (
                detail.display && (
                  <div
                    key={index}
                    className="edit__item u_display_flex u_align_items"
                  >
                    <p className="edit__header">{detail.label}</p>
                    <div className="edit__input">
                      <Input
                        type={detail.type}
                        placeholder={detail.placeholder}
                        value={detail.value}
                        onValueChange={(event) => {
                          handleValueChange(event);
                        }}
                        isRequired={detail.required === 0 ? true : false}
                        name={detail.name}
                        max_length={detail.max_length}
                        min_length={detail.min_length}
                        id={detail.id}
                        isDisabled={false}
                      />
                    </div>
                  </div>
                )
              );
            })}
            <div className="u_display_flex u_justify-content_evenly">
              <Button
                className="edit__store__btn-edit"
                id="updateManager"
                buttonClick={(event) => {
                  handleUpdate(event);
                }}
              >
                Update
              </Button>
              <Button
                className="edit__store__btn-edit"
                id="cancelManagerUpdate"
                buttonClick={(event) => {
                  handleCancel(event);
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <Loader />
        )
      ) : null}

      {isAddSlot ? (
        slotDetails && slotDetails.length ? (
          <div>
            {slotDetails.map((slot, index) => {
              return (
                slot.display && (
                  <div
                    key={index}
                    className="edit__item u_display_flex u_align_items"
                  >
                    <p className="edit__header">{slot.label}</p>
                    {!slot.drop_down_search ? (
                      <div className="edit__input">
                        <Input
                          type={slot.type}
                          placeholder={slot.placeholder}
                          value={
                            (slot.name === "store_code"
                              ? editStoreCode
                              : slot.value) ||
                            (slot.name === "week_day"
                              ? slot.value
                                ? slot.value
                                : 0
                              : slot.value)
                          }
                          onValueChange={(event) => {
                            handleValueChange(event);
                          }}
                          isRequired={slot.required === 0 ? true : false}
                          name={slot.name}
                          max_length={slot.max_length}
                          min_length={slot.min_length}
                          id={slot.id}
                          isDisabled={slot.name === "store_code" ? true : false}
                          className={
                            slot.type === "time" ? "edit__pointer" : ""
                          }
                        />
                      </div>
                    ) : (
                      <div className="edit__input">
                        <Dropdown
                          option={slot.options}
                          onChange={(event) => {
                            handleValueChange(event);
                          }}
                          className="edit__pointer"
                          placeholder={slot.placeholder}
                          value={
                            (slot.name === "store_code"
                              ? editStoreCode
                              : slot.value) ||
                            (slot.name === "week_day"
                              ? slot.value
                                ? slot.value
                                : 0
                              : slot.value)
                          }
                          onValueChange={(event) => {
                            handleValueChange(event);
                          }}
                          isRequired={slot.required === 0 ? true : false}
                          name={slot.name}
                          id={slot.id}
                        />
                      </div>
                    )}
                  </div>
                )
              );
            })}
            <div className="u_display_flex u_justify-content_evenly">
              <Button
                className="edit__store__btn-edit"
                id={isAddSlot ? "addSlot" : "updateSlot"}
                buttonClick={(event) => {
                  handleUpdate(event);
                }}
              >
                {isAddSlot ? "Add" : "Update"}
              </Button>
              <Button
                className="edit__store__btn-edit"
                id={isAddSlot ? "cancelAddSlot" : "cancelSlotUpdate"}
                buttonClick={(event) => {
                  handleCancel(event);
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <Loader />
        )
      ) : null}

      {editStoreCode && !isAddSlot && !isAddPinCode && !editSlotId ? (
        storeDetails && storeDetails.length ? (
          <div>
            {storeDetails.map((store, index) => {
              return (
                store.display && (
                  <div
                    key={index}
                    className="edit__item u_display_flex u_align_items"
                  >
                    <p className="edit__header edit__width54">{store.label}</p>
                    <div className="edit__input">
                      <Input
                        type={store.type}
                        placeholder={store.placeholder}
                        value={store.value}
                        onValueChange={(event) => {
                          handleValueChange(event);
                        }}
                        isRequired={store.required === 0 ? true : false}
                        name={store.name}
                        max_length={store.max_length}
                        min_length={store.min_length}
                        id={store.id}
                        isDisabled={
                          store.name === "dc_city" || store.name === "city"
                            ? true
                            : false
                        }
                      />
                    </div>
                  </div>
                )
              );
            })}
            <div className="u_display_flex u_justify-content_evenly">
              <Button
                className="edit__store__btn-edit"
                id="updateStore"
                buttonClick={(event) => {
                  handleUpdate(event);
                }}
              >
                Update
              </Button>
              <Button
                className="edit__store__btn-edit"
                id="cancelStoreUpdate"
                buttonClick={(event) => {
                  handleCancel(event);
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <Loader />
        )
      ) : null}

      {isAddPinCode ? (
        deliveryPinCodes && deliveryPinCodes.length ? (
          <div>
            {deliveryPinCodes.map((pinCode, index) => {
              return (
                pinCode.display && (
                  <div
                    key={index}
                    className="edit__item u_display_flex u_align_items"
                  >
                    <p className="edit__header edit__width40">
                      {pinCode.label}
                    </p>
                    <div className="edit__input">
                      <Input
                        type={pinCode.type}
                        placeholder={pinCode.placeholder}
                        value={
                          pinCode.name === "store_code"
                            ? editStoreCode
                            : pinCode.value
                        }
                        onValueChange={(event) => {
                          handleValueChange(event);
                        }}
                        isRequired={pinCode.required === 0 ? true : false}
                        name={pinCode.name}
                        max_length={pinCode.max_length}
                        min_length={pinCode.min_length}
                        id={pinCode.id}
                        isDisabled={
                          pinCode.name === "store_code" ? true : false
                        }
                      />
                    </div>
                  </div>
                )
              );
            })}
            <div className="u_display_flex u_justify-content_evenly edit__code__btn edit__width30">
              <Button
                className="edit__store__btn-edit edit__width130"
                id="addPincode"
                buttonClick={(event) => {
                  handleUpdate(event);
                }}
              >
                Add
              </Button>
              <Button
                className="edit__store__btn-edit edit__width130"
                id="cancelAddPincode"
                buttonClick={(event) => {
                  handleCancel(event);
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <Loader />
        )
      ) : null}
    </div>
  );
};

EditDetails.prototype = {
  editManagerId: PropTypes.string,
  editSlotId: PropTypes.string,
  editStoreId: PropTypes.string,
  isAddSlot: PropTypes.bool,
  isEditPincode: PropTypes.bool,
  isAddPinCode: PropTypes.bool,
};

EditDetails.defaultProps = {
  editManagerId: "",
  editSlotId: "",
  editStoreId: "",
  isAddSlot: false,
  isEditPincode: false,
  isAddPinCode: false,
};

export default EditDetails;
