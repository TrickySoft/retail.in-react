import React, { useEffect, useState } from 'react';
import './index.scss';
import {
    getStoreDetails, getCustomerDetails, getOrderDetails, deleteSlotDetails, getStoreLevelStoreOrderDetails,
    getSlotDetails, getStoreManagerOrderDetails, getStoreItemDetails, getStoreDeliveryPincodes, deletePinCode
} from '../api/details';
import PropTypes from 'prop-types';
import left from 'assets/images/left.png';
import Loader from '../../components/loader';
import EditDetails from './editDetails';
import Button from '../../components/button';
import Confirm from 'app/containers/header/confirm';
import { Analytics } from '../../helpers/analytics';

const Details = ({ storeCode, phoneNumber, orderId, onClickNavaigate, isFromStorePage }) => {
    const store_Code = localStorage.getItem('storeCode');
    const order_id = localStorage.getItem('orderId');
    const phone_no = localStorage.getItem('phoneNumber');
    const orderStoreCode = localStorage.getItem('orderStoreCode');

    const [storeDetails, setStoreDetails] = useState([]);
    const [customerDetails, setCustomerDetails] = useState([]);
    const [orderDetails, setOrderDetails] = useState([]);
    const [managerDetails, setManagerDetails] = useState([]);
    const [isShowManagerDetails, setIsShowManagerDetails] = useState(false);
    const [isShowEmpty, setIsShowEmpty] = useState(false);
    const [isShowOrderEmpty, setIsShowOrderEmpty] = useState(false);
    const [isShowStoreEmpty, setIsShowStoreEmpty] = useState(false);
    const [isDisplay, setIsDisplay] = useState(false);
    const [isShowPincodeEmpty, setIsShowPincodeEmpty] = useState(false);
    const [slotDetails, setSlotDetails] = useState([]);
    const [itemDetails, setitemDetails] = useState([]);
    const [pinCodes, setPinCodes] = useState([]);
    const [dataPinCodeAccessor, setDataPinCodeAccessor] = useState({});
    const [dataAccessor, setDataAccessor] = useState({});
    const [managerDataAccessor, setManagerDataAccessor] = useState({});
    const [dataItemAccessor, setDataItemAccessor] = useState({});
    const [storeCodePayload, setStoreCodePayload] = useState({ store_code: storeCode ? storeCode : store_Code });
    const [orderStoreCodePayload, setOrderStoreCodePayload] = useState({ store_code: storeCode ? storeCode : orderStoreCode })

    const [orderPayload, setOrderPayload] = useState({ order_id: orderId ? orderId : order_id })
    const [phoneNumberPayload, setPhoneNumberPayload] = useState({ phone_no: phoneNumber ? phoneNumber : phone_no })

    const [deleteData, setDeleteData] = useState({});
    const [isAddPinCode, setIsAddPinCode] = useState(false);

    const [isAddSlot, setIsAddSlot] = useState(false);
    const [isShowStore, setIsShowStore] = useState(true);
    const [isShowSlots, setISShowSlots] = useState(false);
    const [isShowManager, setIsShowManager] = useState(false);
    const [isEditManager, setIsEditManager] = useState(false);
    const [isEditSlots, setIsEditSlots] = useState(false);
    const [isEditStore, setIsEditStore] = useState(false);
    const [editManagerId, setEditManagerId] = useState('');
    const [editSlotId, setEditSlotId] = useState('');
    const [editStoreCodeId, setEditStoreCodeId] = useState('');
    const [editStoreCode, setEditStoreCode] = useState('');
    const [isDeleteData, setIsDeleteData] = useState(false);
    const [isEditPincode, setIsEditPincode] = useState(false);

    useEffect(() => {
        if (isFromStorePage) {
            getStoreLevelData();
        } else {
            getData();
        }
    }, [])


    const getStoreLevelData = () => {
        getStoreOrderDetails();
        getStoreSlotDetails();
        getStoreManagerDetails();
        getPincodes();
    }

    const getStoreOrderDetails = () => {
        setIsShowStoreEmpty(true);
        getStoreLevelStoreOrderDetails((response) => {
            const { message, content } = response;
            if (message === 'SUCCESS') {
                setIsShowStoreEmpty(false);
                setStoreDetails(content.content);
            } else { setIsShowStoreEmpty(false); }
        }, storeCodePayload);
    }

    const getStoreSlotDetails = () => {
        setIsDisplay(true);
        getSlotDetails((response) => {
            const { message, content } = response;
            if (message === 'SUCCESS') {
                const columns = [];
                Object.entries(content.structure).map(([key, value, i]) => {
                    if (value !== 'Id') {
                        columns.push({
                            key: key,
                            'name': value
                        })
                    }
                    return columns;
                })
                if (columns.length) {
                    setDataAccessor(columns);
                    setSlotDetails(content.content);
                    setIsDisplay(false);
                }
            } else { setIsDisplay(false); }
        }, storeCodePayload);
    }

    const getStoreManagerDetails = () => {
        setIsShowManagerDetails(true);
        getStoreManagerOrderDetails((response) => {
            const { message, content } = response;
            if (message === 'SUCCESS') {
                const columns = [];
                Object.entries(content.structure).map(([key, value, i]) => {
                    if (value !== 'Id') {
                        columns.push({
                            key: key,
                            'name': value
                        })
                    }
                    return columns;
                })
                if (columns.length) {
                    setManagerDataAccessor(columns);
                    setManagerDetails(content.content);
                    if (content.content.length) {
                        setIsShowManagerDetails(false);
                    }
                }
            } else { setIsShowManagerDetails(false); }
        }, storeCodePayload);
    }

    const getPincodes = () => {
        setIsShowPincodeEmpty(true);
        getStoreDeliveryPincodes((response) => {
            const { message, content } = response;
            if (message === 'SUCCESS') {
                const columns = [];
                Object.entries(content.structure).map(([key, value, i]) => {
                    if (value !== 'Id') {
                        columns.push({
                            key: key,
                            'name': value
                        })
                    }
                    return columns;
                })
                if (columns.length) {
                    setDataPinCodeAccessor(columns);
                    setPinCodes(content.content);
                    setIsShowPincodeEmpty(false);
                }
            } else { setIsShowPincodeEmpty(false); }
        }, storeCodePayload);
    }

    const getData = () => {
        if (orderPayload) {
            setIsDisplay(true);
            setIsShowOrderEmpty(true);

            getStoreItemDetails((response) => {
                const { message, content } = response;
                if (message === 'SUCCESS') {
                    const columns = [];
                    Object.entries(content.structure).map(([key, value, i]) => {
                        return columns.push({
                            key: key,
                            'name': value
                        })
                    })
                    if (columns.length) {
                        setDataItemAccessor(columns);
                        setitemDetails(content.content);
                        setIsDisplay(false);
                    }
                } else { setIsDisplay(false); }
            }, orderPayload)

            getOrderDetails((response) => {
                const { message, content } = response;
                if (message === 'SUCCESS') {
                    setOrderDetails(content.content);
                    setIsShowOrderEmpty(false);
                }
            }, orderPayload);
        }

        if (orderStoreCodePayload) {
            setIsShowStoreEmpty(true);
            getStoreDetails((response) => {
                const { message, content } = response;
                if (message === 'SUCCESS') {
                    setIsShowStoreEmpty(false);
                    setStoreDetails(content.content);
                } else { setIsShowStoreEmpty(false); }
            }, orderStoreCodePayload);
        }

        if (phoneNumberPayload) {
            setIsShowEmpty(true);
            getCustomerDetails((response) => {
                const { message, content } = response;
                if (message === 'SUCCESS') {
                    setCustomerDetails(content.content);
                    setIsShowEmpty(false);
                } else { setIsShowEmpty(false); }
            }, phoneNumberPayload);
        }
    }

    const handleTabs = (event) => {
        if (event.target.id === 'showStore') {
            setISShowSlots(false);
            setIsShowManager(false);
            setIsShowStore(true);
        } else if (event.target.id === 'showSlots') {
            setIsShowManager(false);
            setIsShowStore(false);
            setISShowSlots(true);
        } else {
            setIsShowStore(false);
            setISShowSlots(false);
            setIsShowManager(true);
        }
    }

    const handleEditDetails = (detail) => {
        if (isShowManager) {
            setIsEditManager(true);
            setEditManagerId(detail.column_1);
        } else if (isShowSlots && detail !== 'addSlot') {
            setIsEditSlots(true);
            setEditSlotId(detail.column_1);
        } else if (isShowStore && detail !== 'addPinCode') {
            setIsEditStore(true);
            setEditStoreCodeId(storeCode);
        } else if (isShowSlots && detail === 'addSlot') {
            setIsAddSlot(true);
            setEditStoreCode(storeCode);
            setIsEditSlots(true);
        } else if (isShowStore && detail === 'addPinCode') {
            setIsAddPinCode(true);
            setEditStoreCode(storeCode);
            setIsEditPincode(true);
        }
    }

    const handleUpdate = (event) => {
        if (event === 'updateManager') {
            setIsEditManager(false);
            setEditManagerId('');
            getStoreManagerDetails();
        } else if (event === 'updateSlot') {
            setIsEditSlots(false);
            setEditSlotId('');
            getStoreSlotDetails();
        } else if (event === 'updateStore') {
            setIsEditStore(false);
            setEditStoreCodeId('');
            getStoreOrderDetails();
        } else if (event === 'cancelManagerUpdate') {
            setIsEditManager(false);
            setEditManagerId('');
        } else if (event === 'cancelSlotUpdate') {
            setIsEditSlots(false);
            setEditSlotId('');
        } else if (event === 'cancelStoreUpdate') {
            setIsEditStore(false);
            setEditStoreCodeId('');
        } else if (event === 'cancelAddSlot') {
            setIsAddSlot(false);
            setIsEditSlots(false);
            setEditStoreCode('');
        } else if (event === 'cancelAddPincode') {
            setIsAddPinCode(false);
            setIsEditPincode(false);
            setEditStoreCode('');
        } else if (event === 'addPincode') {
            setIsAddPinCode(false);
            setIsEditPincode(false);
            setEditStoreCode('');
            getPincodes();
        } else if (event === 'addSlot') {
            setIsAddSlot(false);
            setIsEditSlots(false);
            setEditStoreCode('');
            getStoreSlotDetails();
        }
    }

    const handleCancel = () => {
        setIsDeleteData(false);
    }

    const handleDeleteSlotDetails = (slot) => {
        let payload = {
            id: slot.column_1
        }
        deleteSlotDetails((response) => {
            const { error, message } = response;
            if (message === "SUCCESS") {
                Analytics.logEventWithVariable(Analytics.OnDeleteDetails.deleteDetails, JSON.stringify({
                    slot_capacity: slot.column_4,
                    end_time: slot.column_3,
                    start_time: slot.column_2,
                    week_day: slot.column_5
                }));
                setIsDeleteData(false);
                alert('Slot Deleted!');
                getStoreSlotDetails();
            } else {
                alert("Can not delete, Please, check your internet connection and try again!");
            }
        }, payload)
    }

    const handleDeletePincode = (pincode) => {
        let payload = {
            id: pincode.column_1
        }
        deletePinCode((response) => {
            const { error, message } = response;
            if (message === "SUCCESS") {
                Analytics.logEventWithVariable(Analytics.OnDeleteDetails.deleteDetails, JSON.stringify({ pincode_deleted: pincode.column_2 }));
                setIsDeleteData(false);
                alert('PinCode Deleted!');
                getPincodes();
            } else {
                alert("Can not delete, Please, check your internet connection and try again!")
            }
        }, payload)
    }


    return (
        <div>
            <div className='details__wrapper' >
                <img className='details__wrapper__arrowIcon' src={left} alt='back-navigation' onClick={onClickNavaigate} />
                {!isFromStorePage ? (
                    <div>
                        <div className='details__wrapper__mr2'> Order ID : {orderPayload.order_id}</div>
                        <div className=' u_display_flex details__wrapper__align'>
                            <div className='details__wrapper__container'>
                                <div className='details__wrapper__header-box'>
                                    <div className='details__wrapper__header'> Store Details :</div>
                                </div>
                                {storeDetails && storeDetails.length ? (
                                    storeDetails.map((item, i) => {
                                        return (
                                            <div className='u_display_flex' key={i}>
                                                <div className='details__wrapper__item-list'>{item.field_name} </div>
                                                <div className='details__wrapper__item'>{item.field_value ? item.field_value : '--'} </div>
                                            </div>
                                        )
                                    })
                                ) : (!isShowStoreEmpty ? (
                                    <div className='u_emptyData'> Store Details are not available </div>
                                ) : <Loader />
                                )
                                }
                            </div>
                            <div className='details__wrapper__container'>
                                <div className='details__wrapper__header-box'>
                                    <div className='details__wrapper__header'> Customer Details :</div>
                                </div>
                                {customerDetails && customerDetails.length ? (
                                    customerDetails.map((item, i) => {
                                        return (
                                            <div className='u_display_flex' key={i}>
                                                <div className='details__wrapper__item-list'>{item.field_name} </div>
                                                <div className='details__wrapper__item'>{item.field_value ? item.field_value : '--'} </div>
                                            </div>
                                        )
                                    })
                                ) : (!isShowEmpty ? (
                                    <div className='u_emptyData details__wrapper-data'> Customer Details are not available </div>
                                ) : <Loader />)
                                }
                            </div>
                        </div>

                        <div className='0'> Order Details :</div>
                        <table className='details__wrapper__table'>
                            {(orderDetails && orderDetails.length) ? (
                                <tbody>
                                    <tr className='details__wrapper__table__header '>
                                        {orderDetails.map((item, i) => (
                                            <th className='details__wrapper__header__row'
                                                key={i}>{item.field_name}</th>
                                        ))}
                                    </tr>
                                    <tr >
                                        {orderDetails.map((item, j) => {
                                            return (<td key={j} className='details__wrapper__data'>
                                                {Array.isArray(item.field_value) ?
                                                    (item.field_value.length) : (item.field_value ? item.field_value : '--')}</td>
                                            )
                                        }
                                        )}
                                    </tr>
                                </tbody>
                            ) : (!isShowOrderEmpty ? (
                                <div className='u_emptyData details__wrapper-data'> Order Details are not available </div>
                            ) : <Loader />)
                            }
                        </table>

                        <div className='details__wrapper__container'>
                            <div className='details__wrapper__header-box'>
                                <div className='details__wrapper__header'> Items List :</div>
                            </div>
                            <table >
                                {(dataItemAccessor && dataItemAccessor.length) && (itemDetails && itemDetails.length) ? (
                                    <tbody>
                                        <tr className='details__wrapper__table__header'>
                                            {dataItemAccessor.map((data, i) => (
                                                <th className='details__wrapper__header__row'
                                                    key={i}>{data.name}</th>
                                            ))}
                                        </tr>
                                        {itemDetails.map((table, i) => (
                                            <tr key={i}>
                                                {dataItemAccessor.map((data2, j) => (
                                                    <td key={j} className='details__wrapper__slots'>
                                                        {data2.Cell ? <data2.Cell {...table} /> : table[data2.key]}</td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                ) : (!isDisplay ? (
                                    <div className='u_emptyData'> Items List are not available </div>
                                ) : <Loader />)
                                }
                            </table>
                        </div>
                    </div>
                ) : (
                    <div>
                        <div className="menu">
                            <ul className="menu__list">
                                <li className={`menu__list__item menu__list__item--${isShowStore ? 'active' : 'disabled'}`} id='showStore' onClick={(e) => { handleTabs(e) }}>
                                    Store Details
                                </li>
                                <li className={`menu__list__item menu__list__item--${isShowSlots ? 'active' : 'disabled'}`} id='showSlots' onClick={(e) => { handleTabs(e) }}>
                                    Slot Details
                                </li>
                                <li className={`menu__list__item menu__list__item--${isShowManager ? 'active' : 'disabled'}`} id='showManager' onClick={(e) => { handleTabs(e) }}>
                                    Store Manager Details
                                </li>
                            </ul>
                        </div>

                        {
                            isShowStore &&
                            <div className='u_display_flex u_justify-content_between details__wrapper__height'>
                                <div className='details__wrapper__store__container u_oveflow_auto details__wrapper__width60'>
                                    <div className='details__wrapper__header-box u_align_items u_display_flex u_justify-content_between'>
                                        <div className='details__wrapper__header'> Store Details :</div>
                                        {
                                            !isEditStore &&
                                            <Button className="details__wrapper__store__btn-edit" id='editStore' buttonClick={(event) => handleEditDetails(event.target.id)}>
                                                Edit
                                            </Button>
                                        }
                                    </div>
                                    {!isEditStore ? (
                                        storeDetails && storeDetails.length ? (
                                            storeDetails.map((item, i) => {
                                                return (
                                                    <div className='u_display_flex' key={i}>
                                                        <div className='details__wrapper__item-store-list'>{item.field_name} </div>
                                                        <div className='details__wrapper__item'>{item.field_value ? item.field_value : '--'} </div>
                                                    </div>
                                                )
                                            })
                                        ) : (!isShowStoreEmpty ? (
                                            <div className='u_emptyData'> Store Details are not available </div>
                                        ) : <Loader />)
                                    ) : (
                                        <EditDetails editStoreCode={editStoreCodeId} onHandleUpdate={(event) => { handleUpdate(event) }} />
                                    )
                                    }
                                </div>
                                <div className='u_oveflow_auto details__wrapper__width25 details__wrapper__store__container'>
                                    <div className='details__wrapper__header-box u_align_items u_display_flex u_justify-content_between'>
                                        <div className='details__wrapper__header'> Store Delivery PinCodes :</div>
                                        {
                                            !isEditPincode &&
                                            <Button className="details__wrapper__store__btn-edit details__wrapper__width137" id='addPinCode' buttonClick={(event) => handleEditDetails(event.target.id)}>
                                                Add PinCode
                                            </Button>
                                        }
                                    </div>
                                    {!isEditPincode ? (
                                        <table >
                                            {(dataPinCodeAccessor && dataPinCodeAccessor.length) && (pinCodes && pinCodes.length) ? (
                                                <tbody>
                                                    <tr className='details__wrapper__table__header'>
                                                        {dataPinCodeAccessor.map((data, i) => (
                                                            <th className='details__wrapper__width27 details__wrapper__header__row '
                                                                key={i}>{data.name}</th>
                                                        ))}
                                                    </tr>
                                                    {pinCodes.map((table, i) => (
                                                        <tr key={i}>
                                                            {dataPinCodeAccessor.map((data2, j) => (
                                                                <td key={j} className='details__wrapper__slots'>
                                                                    {data2.Cell ? <data2.Cell {...table} /> : table[data2.key]}</td>
                                                            ))}
                                                            {/* <td className='details__wrapper__btn'><Button className="details__wrapper__btn-edit" buttonClick={() => handleEditDetails(table)}>
                                                                Edit
                                                            </Button>
                                                            </td> */}
                                                            <td className='details__wrapper__width10 details__wrapper__pad0'>
                                                                <Button className='details__wrapper__btn-edit' buttonClick={() => { setIsDeleteData(true); setDeleteData(table) }}>Delete</Button>
                                                            </td>
                                                            {isDeleteData &&
                                                                <Confirm onCancelLogout={() => { handleCancel() }} onHandleLogout={() => { handleDeletePincode(deleteData) }} logoutText={"Are you sure you want to delete ?"} buttonText={"Delete"} />
                                                            }
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            ) : (!isShowPincodeEmpty ? (
                                                <div className='u_emptyData'> Store Delivery PinCodes are not available </div>
                                            ) : <Loader />)
                                            }
                                        </table>
                                    ) : (
                                        <EditDetails editStoreCode={editStoreCode} isAddPinCode={isAddPinCode} onHandleUpdate={(event) => { handleUpdate(event) }} />
                                    )
                                    }
                                </div>
                            </div>
                        }
                        {
                            isShowSlots &&
                            <div className={`${!isEditSlots ? 'u_display_flex details__wrapper__height ' : 'u_display_flex u_justify-content_center'}`} >
                                <div className={`${!isEditSlots ? 'u_oveflow_auto details__wrapper__store__container details__wrapper__width100 ' : 'u_oveflow_auto details__wrapper__store__container'}`}>
                                    <div className='details__wrapper__header-box u_align_items u_display_flex u_justify-content_between'>
                                        <div className='details__wrapper__header'> Slot Details :</div>
                                        {
                                            !isEditSlots &&
                                            <Button className="details__wrapper__store__btn-edit" id='addSlot' buttonClick={(event) => handleEditDetails(event.target.id)}>
                                                Add Slot
                                            </Button>
                                        }
                                    </div>
                                    {!isEditSlots ? (
                                        <table >
                                            {(dataAccessor && dataAccessor.length) && (slotDetails && slotDetails.length) ? (
                                                <tbody>
                                                    <tr className='details__wrapper__table__header'>
                                                        {dataAccessor.map((data, i) => (
                                                            <th className='details__wrapper__width27 details__wrapper__header__row '
                                                                key={i}>{data.name}</th>
                                                        ))}
                                                    </tr>
                                                    {slotDetails.map((table, i) => (
                                                        <tr key={i}>
                                                            {dataAccessor.map((data2, j) => (
                                                                <td key={j} className='details__wrapper__slots'>
                                                                    {data2.Cell ? <data2.Cell {...table} /> : table[data2.key]}</td>
                                                            ))}
                                                            {/* <td className='details__wrapper__btn'>
                                                                <Button className="details__wrapper__btn-edit" buttonClick={() => handleEditDetails(table)}>
                                                                    Edit
                                                                </Button>
                                                            </td> */}
                                                            <td className='details__wrapper__btn '>
                                                                <Button className='details__wrapper__btn-edit' buttonClick={() => { setIsDeleteData(true); setDeleteData(table) }}>Delete</Button>
                                                            </td>
                                                            {isDeleteData && <td>
                                                                <Confirm className='details__wrapper__overlay' onCancelLogout={() => { handleCancel() }} onHandleLogout={() => { handleDeleteSlotDetails(deleteData) }} logoutText={"Are you sure you want to delete ?"} buttonText={"Delete"} />
                                                            </td>}
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            ) : (!isDisplay ? (
                                                <div className='u_emptyData'> Slot Details are not available </div>
                                            ) : <Loader />)
                                            }
                                        </table>
                                    ) : (
                                        <EditDetails editStoreCode={editStoreCode} editSlotId={editSlotId} isAddSlot={isAddSlot} onHandleUpdate={(event) => { handleUpdate(event) }} />
                                    )
                                    }
                                </div>
                            </div>
                        }
                        {
                            isShowManager &&
                            <div className='u_display_flex u_justify-content_center' >
                                <div className='u_oveflow_auto details__wrapper__store__container'>
                                    <div className='details__wrapper__header-box details__wrapper__header'> Store Manager Details :</div>
                                    {!isEditManager ? (
                                        <table >
                                            {(managerDataAccessor && managerDataAccessor.length) && (managerDetails && managerDetails.length) ? (
                                                <tbody>
                                                    <tr className='details__wrapper__table__header'>
                                                        {managerDataAccessor.map((data, i) => (
                                                            <th className='details__wrapper__width26 details__wrapper__header__row'
                                                                key={i}>{data.name}</th>
                                                        ))}
                                                    </tr>
                                                    {
                                                        managerDetails.map((table, i) => (
                                                            <tr key={i}>
                                                                {managerDataAccessor.map((detail, j) => (
                                                                    <td key={j} className='details__wrapper__slots'>
                                                                        {detail.Cell ? <detail.Cell {...table} /> : table[detail.key]}</td>
                                                                ))}
                                                                <td className='details__wrapper__btn '>
                                                                    <Button className="details__wrapper__btn-edit" buttonClick={() => handleEditDetails(table)}>
                                                                        Edit
                                                                    </Button>
                                                                </td>
                                                            </tr>
                                                        ))
                                                    }
                                                </tbody>
                                            ) : (isShowManagerDetails ? (
                                                <div className='u_emptyData'> Store Manager Details are not available </div>
                                            ) : <Loader />)
                                            }
                                        </table>
                                    ) : (
                                        <EditDetails editManagerId={editManagerId} onHandleUpdate={(event) => { handleUpdate(event) }} />
                                    )
                                    }

                                </div>
                            </div>
                        }
                    </div>
                )}
            </div>
        </div>
    )
}

Details.propTypes = {
    storeCode: PropTypes.number,
    phoneNumber: PropTypes.string,
    orderId: PropTypes.number,
    isFromStorePage: PropTypes.bool
};

Details.defaultProps = {
    storeCode: 0,
    phoneNumber: '',
    orderId: 0,
    isFromStorePage: false
};

export default Details;

