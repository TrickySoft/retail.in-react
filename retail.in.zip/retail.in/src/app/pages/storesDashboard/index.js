import React, { useEffect, useState } from 'react';
import './index.scss';
import Button from '../../components/button/index';
import Search from '../../components/search/index';
import Table from 'app/components/table';
import { getSearchStoreDetails, getAllStores } from '../api/details';
import Details from '../details';
import Loader from '../../components/loader';
import { Analytics } from '../../helpers/analytics';

const StoresDashboard = () => {
    localStorage.removeItem('isShowOrderDetails');
    localStorage.removeItem('orderSearchKey');
    localStorage.removeItem('orderSearchText');

    const showDetails = localStorage.getItem('isShowStoreDetails');
    const key = localStorage.getItem('storeSearchKey');
    const text = localStorage.getItem('storeSearchText');
    const [searchText, setSearchText] = useState(text ? text : '');
    const [filterData, setFilterData] = useState();
    const [searchKey, setSearchKey] = useState(key ? key : 'Store Code');
    const [dataAccessor, setDataAccessor] = useState({});
    const [storeCode, setStoreCode] = useState(0);
    const [isStoresAvailable, setIsStoresAvailable] = useState(false);
    const [isShowDetails, setIsShowDetails] = useState(showDetails ? showDetails : false);
    const [presentPage, setPresentPage] = useState(0);
    const [searchOrderId, setSearchOrderId] = useState('Enter Store Code');

    useEffect(() => {
        if (!searchText) {
            getStores();
        } else {
            handleSearch();
        }
    }, [])

    const getStores = () => {
        getAllStores((response) => {
            const { message, content } = response;
            if (message === 'SUCCESS') {
                setFilterData(content.content);
                setDataAccessor(content.structure);
            } else {
                alert('Something went wrong, Please try again!');
            }
        })
    }

    const searchHandler = (e) => {
        let text = e.target.value;
        if (text < 0) {
            text = '';
        }
        setSearchText(text);
        if (!text.length) {
            clearTextHandler();
        }
    };

    const handleSearch = () => {
        let payload
        if (searchKey === 'Store Code') {
            payload = {
                store_code: searchText
            }
        } else if (searchKey === 'PinCode') {
            payload = {
                pincode: searchText
            }
        }
        getSearchStoreDetails((response) => {
            const { message, content } = response;
            if (message === 'SUCCESS') {
                setFilterData(content.content);
                setDataAccessor(content.structure);
                setIsStoresAvailable(true);
                Analytics.logEventWithVariable(Analytics.SearchStore.searchStore, JSON.stringify({ searchedKey: payload }));
            } else if(searchKey === 'Store Code') {
                alert('Please enter valid Store Code...');
            }else{
                alert('Please enter valid Pin Code...');
            }
        }, payload)
    }

    const clearTextHandler = () => {
        localStorage.removeItem('isShowStoreDetails');
        localStorage.removeItem('storeSearchKey');
        localStorage.removeItem('storeSearchText');
        setDataAccessor({});
        setFilterData([]);
        setSearchText('');
        setStoreCode(0);
        getStores();
    };

    const handleFilterData = (event) => {
        setSearchText('');
        setStoreCode(0);
        let searchItem = event?.target.value;
        if (searchItem === 'Store Code') {
            setSearchOrderId('Enter Store Code')
        } else if (searchItem === 'PinCode') {
            setSearchOrderId('Enter PinCode');
        }
        setSearchKey(searchItem);
    }

    const handleNavigation = (table, page) => {
        localStorage.setItem('storeCode', table.column_2);
        if (searchKey === 'Store Code' || searchKey === 'PinCode') {
            setStoreCode(table.column_2);
        }
        Analytics.logEventWithVariable(Analytics.StoreClicked.storeClicked, JSON.stringify({ store_code: table.column_2 }));
        setIsShowDetails(true);
        localStorage.setItem('isShowStoreDetails', true);
        setPresentPage(page);
        localStorage.setItem('storeSearchKey', searchKey);
        localStorage.setItem('storeSearchText', searchText);
    }

    const handleBackNaviagtion = () => {
        setSearchText(localStorage.getItem('storeSearchText'));
        setSearchKey(localStorage.getItem('storeSearchKey'));
        localStorage.removeItem('isShowStoreDetails');
        localStorage.removeItem('storeCode');
        setIsShowDetails(false);
        if (searchText) {
            handleSearch();
        }
    }

    const handleDataOnEnter = (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    }

    return (
        <div >
            {!isShowDetails ? (
                <div className="store ">
                    <br />
                    <div className="store__filter">
                        <div className="filter__searchWrapper">
                            <select className='store__select' value={searchKey} onChange={handleFilterData} required={false}>
                                <option value='Store Code'> Store Code </option>
                                <option value='PinCode'> PinCode </option>
                            </select>
                            <Search
                                value={searchText}
                                onChange={searchHandler}
                                placeholder={searchOrderId}
                                clearTextHandler={clearTextHandler}
                                classname="filter__searchWrapper__searchBar"
                                handleKeyEnter={handleDataOnEnter}
                            />
                            <Button isBtnDisabled={(searchText !== '') ? false : true} buttonClick={() => { handleSearch(); }}>
                                Search
                            </Button>
                        </div>
                    </div>
                    <div className="store__tableWrapper">
                        {filterData && filterData.length ? (
                            <Table data={filterData} dataAccessor={dataAccessor} presentPage={presentPage} onRowClick={handleNavigation} />
                        ) : ((Object.entries(dataAccessor).length !== 0) ?
                            (!isStoresAvailable ? (
                                <div className='u_emptyData'> Store not available  </div>
                            ) : (
                                <div className='u_emptyData'>  Stores not available  </div>
                            )
                            ) : (
                                <Loader />
                            )
                        )
                        }
                    </div>
                </div>
            ) : (
                <div >
                    <Details isFromStorePage={true} storeCode={storeCode} onClickNavaigate={handleBackNaviagtion} />
                </div>
            )
            }
        </div>
    );
};

export default StoresDashboard;
