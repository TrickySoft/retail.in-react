import { fetchCallLogin, fetchCall } from '../../utils/ajax';
import { API_CONSTANTS, API_METHODS } from '../../constants/api-constants';

export const getLoginDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.LOGIN_DATA}`;
  return fetchCallLogin((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getStoreOrderDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.SEARCH_ORDER}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getStoreDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.STORE_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload)
};

export const getCustomerDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.CUSTOMER_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload)
};

export const getOrderDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.ORDER_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload)
};

export const getSearchStoreDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.SEARCH_STORE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload)
};

export const getStoreLevelStoreOrderDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.STORE_ORDER_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload)
};


export const getSlotDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_SLOT_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload)
};

export const getAllStores = (callback) => {
  const url = `${API_CONSTANTS.GET_STORES}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
};

export const getStoreManagerOrderDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_STORE_MANAGER_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
};

export const getStoreItemDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.ORDER_ITEM_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const editManagerDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.EDIT_MANAGER_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const editSlotDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.EDIT_SLOT_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const updateManagerDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_MANAGER_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const updateSlotDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_SLOT_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const getStoreDeliveryPincodes = (callback, payload) => {
  const url = `${API_CONSTANTS.GET_DELIVERY_PINCODES}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const editStoreDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.EDIT_STORE_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const updateStoreDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_STORE_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const deleteSlotDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.DELETE_SLOT_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const addSlotDetails = (callback) => {
  const url = `${API_CONSTANTS.ADD_SLOT_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
}

export const createSlotDetails = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_SLOT_DETAILS}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const editStoreDeliveryPincodes = (callback, payload) => {
  const url = `${API_CONSTANTS.EDIT_DELIVERY_PINCODE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const updatePincode = (callback, payload) => {
  const url = `${API_CONSTANTS.UPDATE_DELIVERY_PINCODE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const deletePinCode = (callback, payload) => {
  const url = `${API_CONSTANTS.DELETE_PINCODE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}

export const addPinCode = (callback) => {
  const url = `${API_CONSTANTS.ADD_PINCODE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.GET);
}

export const createPinCode = (callback, payload) => {
  const url = `${API_CONSTANTS.CREATE_PINCODE}`;
  return fetchCall((response) => {
    callback(response);
  }, url, API_METHODS.POST, payload);
}