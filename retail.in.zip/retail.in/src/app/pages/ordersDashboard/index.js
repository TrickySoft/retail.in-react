import React, { useState, useEffect } from 'react';
import './index.scss';
import Button from '../../components/button/index';
import Search from '../../components/search/index';
import Table from 'app/components/table';
import { getStoreOrderDetails } from '../api/details';
import Details from '../details';
import Loader from '../../components/loader';
import { Analytics } from '../../helpers/analytics';

const OrdersDashboard = () => {
  localStorage.removeItem('isShowStoreDetails');
  localStorage.removeItem('storeSearchKey');
  localStorage.removeItem('storeSearchText');

  const showDetails = localStorage.getItem('isShowOrderDetails');
  const key = localStorage.getItem('orderSearchKey');
  const text = localStorage.getItem('orderSearchText');
  const [searchText, setSearchText] = useState(text ? text : '');
  const [filterData, setFilterData] = useState();
  const [searchKey, setSearchKey] = useState(key ? key : 'Order Id');
  const [dataAccessor, setDataAccessor] = useState({});
  const [storeCode, setStoreCode] = useState(0);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [orderId, setOrderId] = useState(0);
  const [isShowDetails, setIsShowDetails] = useState(showDetails ? showDetails : false);
  const [presentPage, setPresentPage] = useState(0);
  const [searchOrderId, setSearchOrderId] = useState('Enter Order Id');
  const [isShowLoader, setIsShowLoader] = useState(false);

  useEffect(() => {
    if (searchText) {
      handleSearch();
    }
  }, [])

  const searchHandler = (e) => {
    const text = e.target.value;
    let count = text.length;
    if (!count) {
      clearTextHandler();
    } else if (searchKey === 'Phone Number' && count <= 10) {
      setSearchText(text);
    } else if (searchKey === 'Order Id') {
      setSearchText(text);
    }
  }

  const validatePhone = (phone) => {
    const phoneReg = /^[789][0-9]{9}$/;
    return phoneReg.test(phone);
  }

  const handleSearch = () => {
    if (searchKey === 'Phone Number' && !validatePhone(searchText)) {
      alert("Please enter the valid mobile number!");
      clearTextHandler();
    } else {
      setIsShowLoader(true);
      let payload
      if (searchKey === 'Order Id') {
        payload = {
          order_id: searchText
        }
      } else if (searchKey === 'Phone Number') {
        payload = {
          phone_no: searchText
        }
      }

      getStoreOrderDetails((response) => {
        const { message, content } = response;
        if (message === 'SUCCESS') {
          setFilterData(content.content);
          setDataAccessor(content.structure);
          setIsShowLoader(false);
          Analytics.logEventWithVariable(Analytics.Onsearch.search, JSON.stringify({ search: searchText }));
        } else {
          setSearchText('');
          alert('Please enter valid Order Id or Phone Number...');
          setIsShowLoader(false);
        }
      }, payload)
    }
  }

  const clearTextHandler = () => {
    localStorage.removeItem('isShowOrderDetails');
    localStorage.removeItem('orderSearchKey');
    localStorage.removeItem('orderSearchText');
    setDataAccessor({});
    setFilterData([]);
    setSearchText('');
  };

  const handleFilterData = (event) => {
    setSearchText('');
    setFilterData([]);
    let searchItem = event?.target.value;
    if (searchItem === 'Order Id') {
      setSearchOrderId('Enter Order Id')
    }
    else if (searchItem === 'Phone Number') {
      setSearchOrderId('Enter Phone Number')
    }
    setSearchKey(searchItem);
  }

  const handleNavigation = (table, page) => {
    localStorage.setItem('orderStoreCode', table.column_4);
    localStorage.setItem('orderId', table.column_1);
    localStorage.setItem('phoneNumber', table.column_6);
    localStorage.setItem('isShowOrderDetails', true);
    Analytics.logEventWithVariable(Analytics.OrderClick.orders, JSON.stringify({ order_id: table.column_1 }));
    setOrderId(table.column_1);
    setStoreCode(table.column_4);
    setPhoneNumber(table.column_6);
    setIsShowDetails(true);
    setPresentPage(page);
    localStorage.setItem('orderSearchKey', searchKey);
    localStorage.setItem('orderSearchText', searchText);
  }

  const handleBackNaviagtion = () => {
    localStorage.removeItem('orderStoreCode');
    localStorage.removeItem('orderId');
    localStorage.removeItem('phoneNumber');
    localStorage.removeItem('isShowOrderDetails');
    setIsShowDetails(false);
    if (searchText) {
      handleSearch();
    }
  }

  const handleDataOnEnter = (e) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  }

  return (
    <div >
      {!isShowDetails ? (
        <div className='dashboard '>
          <br />
          <div className='dashboard__filter'>
            <div className='filter__searchWrapper'>
              <select className='dashboard__select' value={searchKey} onChange={handleFilterData} required={false}>
                <option value='Order Id'> Order Id </option>
                <option value='Phone Number'> Phone Number </option>
              </select>
              <Search
                value={searchText}
                onChange={searchHandler}
                type='number'
                placeholder={searchOrderId}
                clearTextHandler={clearTextHandler}
                classname='filter__searchWrapper__searchBar'
                handleKeyEnter={handleDataOnEnter}
              />
              <Button isBtnDisabled={(searchText !== '') ? false : true} buttonClick={() => { handleSearch(); }}>
                Search
              </Button>
            </div>
          </div>
          <div className='dashboard__tableWrapper'>
            {filterData && filterData.length ? (
              <Table data={filterData} dataAccessor={dataAccessor} presentPage={presentPage} onRowClick={handleNavigation} />
            ) : ((Object.entries(dataAccessor).length !== 0) ? (
              <div className='u_emptyData'> Order not available  </div>
            ) : (
              isShowLoader ? (
                <Loader />
              ) : (
                <div className='u_emptyData'> Please search by Order Id or Phone Number  </div>
              )))
            }
          </div>
        </div>
      ) : (
        <div >
          <Details storeCode={storeCode} orderId={orderId} phoneNumber={phoneNumber} onClickNavaigate={handleBackNaviagtion} />
        </div>
      )
      }
    </div>
  );
};

export default OrdersDashboard;