const searchEvent = (data) => {
    try {
    window.dataLayer.push({
    event: data.eventName,
    });
    } catch (ex) {
    console.log('Exception:', ex);
    }
    };

    const searchEventWithVariable = (data, action) => {
        try {
        if (data) {
        if (data.key) {
        let info = {
        event: data.eventName,
        };
        info[data.key] = action;
        window.dataLayer.push(info);
        } else {
        window.dataLayer.push({
        event: data.eventName,
        });
        }
        }
        }catch(ex){
        console.log('Exception:', ex);
        }
        }

        const Onsearch = {
            search: {
            eventName: 'search', //tagname and eventname
            key: 'search',
            }
            }

        export const Analytics = {
            searchEvent,
            searchEventWithVariable,
            Onsearch
            };