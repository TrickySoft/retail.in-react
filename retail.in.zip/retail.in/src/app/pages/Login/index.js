import React, { useState } from 'react';
import './index.scss';
import Button from '../../components/button/index';
import logo from 'assets/images/More logos-03.svg';
import { useHistory } from 'react-router-dom';
import { getLoginDetails } from '../api/details';
import { Analytics } from '../../helpers/analytics';

const Login = () => {
    const history = useHistory();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isBtnDisabled, setIsBtnDisabled] = useState(true);
    const [isToggle, setIsToggle] = useState(false);

    const hanldeLogin = () => {
        if (validateEmail(email) && password) {
            setIsBtnDisabled(false);
        }
        const payload = {
            email: email,
            password: password
        }
        getLoginDetails((response) => {
            const { message, content } = response;
            if (message === 'Success') {
                let date = new Date();
                let getDate = (date.getDate() + "/" + (+date.getMonth() + +1) + "/" + date.getFullYear());
                let time = (date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
                Analytics.logEventWithVariable(Analytics.Onboarding.login, JSON.stringify({ userName: email, time: time, Date: getDate }));
                
                const roleName = content.name;
                sessionStorage.setItem('userId', content.id);
                sessionStorage.setItem('roleName', roleName);
                const showTabs = content.access_to.tabs[0];
                sessionStorage.setItem('showTabs', showTabs);
                if (showTabs === "ALL") {
                    history.push('/orders');
                } else {
                    history.push('/stores');
                }
            } else {
                alert('Please, try login again with valid credentials...');
            }
        }, payload)
    }

    const validateEmail = (email) => {
        const re = /^(([^<>()[\]\\.,;:\s@']+(\.[^<>()[\]\\.,;:\s@']+)*)|('.+'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }

    const inputHandler = (event, key) => {
        let val = event?.target.value;
        setIsBtnDisabled(true);
        if (key === 1) {
            setEmail(val);
        } else {
            setPassword(val);
        }
        if (validateEmail(email) && password) {
            setIsBtnDisabled(false);
        }
    }

    const handleKeyEnter = (e) => {
        if (e.key === 'Enter' && validateEmail(email) && password) {
            hanldeLogin();
        }
    }

    const handleToggle = () => {
        setIsToggle(!isToggle)
    }

    return (
        <div className='login__wrapper'>
            <img src={logo} alt='MORE-Logo' className='login__logo' />
            <div className='u_display_flex u_align_items login__width70' >
                <p className='login__header' >
                    Email
                </p>
                <div className='login__input__width'>
                    <input required type='text' onKeyDown={handleKeyEnter} onChange={(e) => inputHandler(e, 1)} className='login__input' placeholder='Enter Email'></input>
                </div>
            </div>
            <div className='u_display_flex u_align_items login__width70'>
                <p className='login__header' >
                    Password
                </p>
                <div className='login__input__width'>
                    <input required type={`${isToggle ? 'text' : 'password'}`} onKeyDown={handleKeyEnter} onChange={(e) => inputHandler(e, 2)} className='login__input' placeholder='Enter Password' />
                    <span className={`${isToggle ? 'fa fa-eye-slash login__icon' : 'fa fa-eye login__icon'}`} onClick={handleToggle}></span>
                </div>
            </div>
            <Button className='login__button' isBtnDisabled={isBtnDisabled} buttonClick={hanldeLogin}>
                Login
            </Button>
        </div>
    );
};

export default Login;
