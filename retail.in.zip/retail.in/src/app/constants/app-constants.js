export const TOAST_TYPE_CONSTANTS = {
  SUCCESS: 'success',
  ERROR: 'error',
};

export const TEAM_ROLE_CONSTANTS = {
  ADMIN: 'ADMIN',
  MEMBER: 'MEMBER',
  SUPER_ADMIN: 'SUPER_ADMIN',
};