const BaseURL = {
  BASE_URL: `${process.env.REACT_APP_BASE_URL}`
};

export const API_CONSTANTS = {
  LOGIN_DATA: `${BaseURL.BASE_URL}/api/v1/user/login`,
  SEARCH_ORDER: `${BaseURL.BASE_URL}/api/v1/order/orderStatus`,
  STORE_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/storeDetails`,
  CUSTOMER_DETAILS: `${BaseURL.BASE_URL}/api/v1/user/userDetails`,
  ORDER_DETAILS: `${BaseURL.BASE_URL}/api/v1/order/orderDetails`,
  SEARCH_STORE: `${BaseURL.BASE_URL}/api/v1/store/searchStore`,
  STORE_ORDER_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/storeLevelDetails`,
  GET_STORES: `${BaseURL.BASE_URL}/api/v1/store/getAllStores`,
  GET_SLOT_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/storeSlotDetails`,
  GET_STORE_MANAGER_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/storeManagerDetails`,
  ORDER_ITEM_DETAILS: `${BaseURL.BASE_URL}/api/v1/order/itemDetails`,
  EDIT_MANAGER_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/editManagerDetails`,
  EDIT_SLOT_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/editSlotDetails`,
  UPDATE_MANAGER_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/updateManagerDetails`,
  UPDATE_SLOT_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/updateSlotDetails`,
  GET_DELIVERY_PINCODES: `${BaseURL.BASE_URL}/api/v1/store/storeDeliveryPincodeDetails`,
  EDIT_STORE_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/editStoreDetails`,
  UPDATE_STORE_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/updateStoreDetails`,
  DELETE_SLOT_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/deleteSlotDetails`,
  ADD_SLOT_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/addSlotDetails`,
  CREATE_SLOT_DETAILS: `${BaseURL.BASE_URL}/api/v1/store/createSlotDetails`,
  EDIT_DELIVERY_PINCODE: `${BaseURL.BASE_URL}/api/v1/store/editDeliveryPincode`,
  UPDATE_DELIVERY_PINCODE: `${BaseURL.BASE_URL}/api/v1/store/updateDeliveryPincode`,
  DELETE_PINCODE: `${BaseURL.BASE_URL}/api/v1/store/deleteDeliveryPincode`,
  ADD_PINCODE: `${BaseURL.BASE_URL}/api/v1/store/addDeliveryPincode`,
  CREATE_PINCODE: `${BaseURL.BASE_URL}/api/v1/store/createDeliveryPincode`
};

export const API_METHODS = {
  GET: 'GET',
  POST: 'POST',
  DELETE: 'DELETE',
  UPDATE: 'UPDATE',
  PUT: 'PUT',
};
