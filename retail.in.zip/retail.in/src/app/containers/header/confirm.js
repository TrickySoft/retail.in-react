import React from 'react'
import PropTypes from 'prop-types';

const Confirm = ({ onCancelLogout, onHandleLogout, logoutText, buttonText, className }) => {

  const handleClick = e => {
    if (e?.target.id === 'dialog-target') {
      onCancelLogout();
    }
    return;
  }

  return (
    <div>
      <div className={`overlay ${className}`} id='dialog-target' onClick={handleClick}>
        <div className='overlay__dialog'>
          <div className='overlay__dialog__content'>
            <p className='overlay__dialog__description'>{logoutText}</p>
          </div>
          <div className='overlay__dialog__footer u_display_flex u_align_items '>
            <button className='overlay__dialog__cancel' onClick={onCancelLogout}>Cancel</button>
            <button className='overlay__dialog__confirm' onClick={onHandleLogout}>{buttonText}</button>
          </div>
        </div>
      </div>
    </div>
  )
}

Confirm.prototypes = {
  onHandleLogout: PropTypes.func,
  onCancelLogout: PropTypes.func
}

Confirm.defaultProps = {
  onHandleLogout: () => { },
  onCancelLogout: () => { }
}

export default Confirm