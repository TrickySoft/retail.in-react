import React, { useState } from 'react';
import './index.scss';
import logo from 'assets/images/More logos-03.svg';
import { useHistory, useLocation } from 'react-router-dom';
import Confirm from '../header/confirm';
import '../header/confirm.scss';
import Tippy from '@tippy.js/react';
import 'tippy.js/dist/tippy.css';

const Header = () => {
  const history = useHistory();
  const location = useLocation();
  const pathName = location.pathname;
  const RoleName = sessionStorage.getItem('roleName');
  const [showLogout, setShowLogout] = useState(false)
  const showTabs = sessionStorage.getItem('showTabs');

  const handleDirectNavigation = () => {
    if (pathName !== '/') {
      alert('Please login!');
      history.push('/');
      location.pathname = '/';
    }
  }

  const handleLogout = () => {
    history.push('/');
    sessionStorage.clear();
    localStorage.clear();
    setShowLogout(false);
  }

  const handleCancel = () => {
    setShowLogout(false);
  }

  return (
    (pathName !== '/' && RoleName !== null) ? (
      <div className='header'>
        <img src={logo} alt='MORE-Logo' className='header__logo' />
        <div className='header__menu'>
          {showTabs === 'ALL' ? (
            <ul className='menu__list'>
              <li className={`menu__list__item menu__list__item--${pathName === '/orders' ? 'active' : 'disabled'}`}
                onClick={() => { history.push('/orders') }}>
                Orders
              </li>
              <li className={`menu__list__item menu__list__item--${pathName === '/stores' ? 'active' : 'disabled'}`}
                onClick={() => { history.push('/stores') }}>
                Stores
              </li>
            </ul>
          ) : (
            <ul className='menu__list'>
              <li className={`menu__list__item menu__list__item--${pathName === '/stores' ? 'active' : 'disabled'}`}
                onClick={() => { history.push('/stores') }}>
                Stores
              </li>
            </ul>
          )
          }
        </div>

        <div className='header__name' >
          {RoleName === '' || undefined ? '' : (<div >Welcome  &nbsp;{RoleName} ! </div>
          )}
          &nbsp;  &nbsp;  &nbsp;
          <Tippy arrow={false} content='Logout'>
            <div onClick={() => { setShowLogout(true) }}><i className='fas fa-sign-out-alt header__logout__faicon'></i>
            </div>
          </Tippy>
          {
            showLogout && (
              <Confirm onCancelLogout={handleCancel} onHandleLogout={handleLogout}
                logoutText={'Are you sure you want to logout?'} buttonText={'OK'}
              />
            )
          }
        </div>
      </div>
    ) : (<div>
      {handleDirectNavigation()}
    </div>)
  );
};

export default Header;