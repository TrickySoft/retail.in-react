import { Route, Switch, useLocation } from 'react-router-dom';
import Loader from 'app/components/loader';
import React from 'react';
import Login from 'app/pages/Login';
import OrdersDashboard from 'app/pages/ordersDashboard';
import StoresDashboard from 'app/pages/storesDashboard';
import Header from '../containers/header/index';

const Router = () => {
    return (
        <React.Suspense fallback={<Loader />}>
            <Header />
            <Switch>
                <Route exact path='/' component={Login} />
                <Route exact path='/stores' component={StoresDashboard} />
                <Route exact path='/orders' component={OrdersDashboard} />
            </Switch>
        </React.Suspense>
    );
};

export default Router;