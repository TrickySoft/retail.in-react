import 'app/app.scss';
import Router from 'app/router';

function App() {
  return (
    <div>
      <div className='main'>
        <Router />
      </div>
    </div>
  );
}

export default App;
