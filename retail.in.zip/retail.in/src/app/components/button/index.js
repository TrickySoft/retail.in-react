import React from 'react';
import './index.scss';

import PropTypes from 'prop-types';

const Button = (props) => {
  const { children, className, buttonClick, isBtnDisabled, id } = props;
  return <button id={id} className={`buttonStyle  ${isBtnDisabled && 'buttonStyle_disabled'} ${className}`} onClick={(e) => { buttonClick(e); }}
    disabled={isBtnDisabled}>{children}</button>;
};

Button.propTypes = {
  buttonClick: PropTypes.func,
  isBtnDisabled: PropTypes.bool,
  className: PropTypes.string,
  children: PropTypes.string,
  id: PropTypes.string
};

Button.defaultProps = {
  buttonClick: () => { },
  isBtnDisabled: false,
  className: '',
  children: '',
  id: ''
};

export default React.memo(Button);
