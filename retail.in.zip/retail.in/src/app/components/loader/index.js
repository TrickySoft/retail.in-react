import React, { useEffect } from 'react';
import './index.scss';

const Loader = props => {
  useEffect(() => {
  }, [props.loader]);
  return <p className='loader__align'>Loading...</p>
}

export default Loader;
