import React from 'react';
import './index.scss';
import PropTypes from 'prop-types';

const Search = ({
  value,
  placeholder,
  classname,
  onChange,
  clearTextHandler,
  handleKeyEnter,
  type
}) => {
  return (
    <div className={`searchBar ${classname}`}>
      <img
        className='searchBar__searchIcon'
        src='https://www.freeiconspng.com/uploads/search-icon-png-2.png'
        alt='searchIcon'
      />
      <input
        value={value}
        onChange={onChange}
        type={type}
        placeholder={placeholder}
        onKeyDown={handleKeyEnter}
        className={'searchBar__textInput'}
        min={0}
      />
      {value && (
        <img onClick={clearTextHandler}
          className='searchBar__searchIcon searchBar__closeIcon'
          src='https://www.freeiconspng.com/uploads/close-icon-39.png'
          alt='closeIcon'
        />
      )}
    </div>
  );
};

Search.propTypes = {
  className: PropTypes.string,
  value: PropTypes.string,
  type: PropTypes.string,
  placeholder: PropTypes.string,
  classname: PropTypes.string,
  onChange: PropTypes.func,
  clearTextHandler: PropTypes.func
};

Search.defaultProps = {
  classname: '',
  value: 0,
  placeholder: 'search',
  onChange: () => { },
  clearTextHandler: '',
  type: 'number'
};

export default React.memo(Search);
