import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Pagination from './pagination';
import './index.scss';

const pageSize = 10;

const Table = ({ data, dataAccessor, onRowClick, presentPage }) => {
  const [tableData, setTableData] = useState(data);
  const [tableColumn, setTableColumn] = useState([]);

  useEffect(() => {
    const columns = [];
    Object.entries(dataAccessor).map(([key, value, i]) => {
      return columns.push({
        key: key,
        'name': value
      })
    })
    if (columns.length) {
      setTableColumn(columns);
      setTableData(data);
    }
  }, [data, dataAccessor]);

  const handleFilterData = (event) => {
    let pageSize = event?.target.value;
    setcolumnsperPage(pageSize);
    setPaginationNumber();
  }

  const [currentPage, setCurrentPage] = useState(presentPage);
  const [columnsperPage, setcolumnsperPage] = useState(pageSize);
  const setPaginationNumber = (pageNum) => setCurrentPage(pageNum);
  const perPageColumnLength = (currentPage * columnsperPage);
  const startPointer = data.length >= perPageColumnLength ? perPageColumnLength : 0 * columnsperPage;
  const endPointer = + startPointer + + columnsperPage;
  const filteredData = tableData.slice(startPointer, endPointer);

  return (
    <div className='table'>
    <div className = 'table__records'>{endPointer > tableData.length ? startPointer + 1 : endPointer}&nbsp; - &nbsp;{tableData.length}</div>
      <table className='table__wrapper'>
        {(tableColumn && tableColumn.length) && (filteredData && filteredData.length) ? (
          <tbody>
            <tr className='table__wrapper__header__row'>
              {tableColumn.map((data, i) => (
                <th className='table__wrapper__header'
                  key={i}>{data.name}</th>
              ))}
            </tr>
            {filteredData.map((table, i) => (
              <tr key={i} className='table__wrapper__row table__wrapper-data' onClick={() => onRowClick(table, currentPage)}>
                {tableColumn.map((data2, j) => (
                  <td key={j} className='table__wrapper__data'>
                    {data2.Cell ? <data2.Cell {...table} /> : table[data2.key]}</td>
                ))}
              </tr>
            ))}
          </tbody>
        ) : null
        }
      </table>
     
        
     
      <div className='table__main'>
        <div className='table__dropdown'>
          <select className='dashboard__select'
            onChange={handleFilterData} required={false}>
            <option value='10'> 10 </option>
            <option value='20'> 20 </option>
            <option value='30'> 30 </option>
            <option value='50'> 50 </option>
            <option value='100'> 100 </option>
          </select>
        </div>
        <div className='table__pagination'>
          <Pagination
            currentPage={currentPage}
            setPage={setPaginationNumber}
            size={Math.ceil(tableData.length / columnsperPage)}
          /></div>
      </div>
    </div>
  );
};

Table.propTypes = {
  data: PropTypes.array,
  dataAccessor: PropTypes.shape({}),
}

Table.defaultProps = {
  data: [],
  dataAccessor: {},
  checkedItems: []
};

export default Table;
