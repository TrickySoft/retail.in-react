import PropTypes from 'prop-types';

const Pagination = ({ setPage, size, currentPage }) => {

  if (size === 0) return null;

  return (
    <div className='pagination'>

      <div className='pages__layout'> Showing page &nbsp; {currentPage > size ? 1 : currentPage + 1} &nbsp; of &nbsp; {size} </div>
      <div
        
        className={`${currentPage === 0 ? 'pagination__item pagination__disabled-item' : 'pagination__item'}`}
        onClick={() => setPage(currentPage === 0 || currentPage > size ? 0 : currentPage - 1)}
      >
        &laquo;
      </div>

      {Array(size)
        .fill(0)
        .map((_, i) => ((currentPage <= size ? (i === size) || Math.abs(currentPage - i) <= 2 : (currentPage === size)) &&
          (<div
            className={`${'pagination__item'} ${i === currentPage ? 'pagination__item__active' : ''
              }`}
            key={i}
            onClick={() => setPage(i)}
          >
            {i + 1}
          </div>)
        ))}

      <div
        className='pagination__item'
        className={`${currentPage + 1 === size ? 'pagination__item pagination__disabled-item' : 'pagination__item'}`}
        onClick={() =>
          setPage(currentPage === size - 1 ? size - 1 : currentPage + 1)
        }
      >
        &raquo;
      </div>

    </div>
  );
};

Pagination.propTypes = {
  setPage: PropTypes.func,
  size: PropTypes.number,
  currentPage: PropTypes.number
}

Pagination.defaultProps = {
  size: 0,
  currentPage: 0
};

export default Pagination;

