import './index.scss';
import PropTypes from 'prop-types';

const Dropdown = ({ option, onChange, className, placeholder, value, isRequired, name, id, isDisabled }) => {
  return (
    <select onChange={onChange} id={id} name={name} value={value} className={`dropdown ${className}`} required={isRequired} disabled={isDisabled}>
      {/* <option disabled selected value={value}>
        {placeholder}
      </option> */}
      {option.map((element, index) => (
        <option key={index} className='dropdown__pointer'  value={element.value}>{element.label}</option>
      ))}
    </select>
  );
};

Dropdown.propTypes = {
  className: PropTypes.string,
  onChange: PropTypes.func,
  option: PropTypes.array,
  isRequired: PropTypes.bool,
  value: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  isRequired: PropTypes.bool,
  name: PropTypes.string,
  id: PropTypes.string,
  isDisabled: PropTypes.bool
};

Dropdown.defaultProps = {
  className: '',
  onChange: () => { },
  option: [],
  isRequired: false,
  value: 0,
  isRequired: false,
  name: '',
  id: '',
  isDisabled: false
};

export default Dropdown;
