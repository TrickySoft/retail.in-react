const logEvent = (data) => {
  try {
    window.dataLayer.push({
      event: data.eventName,
    });
  } catch (ex) {
    console.log('Exception:', ex);
  }
};

const logEventWithVariable = (data, action) => {
  try {
    if (data) {
      if (data.key) {
        let info = {
          event: data.eventName,
        };
        info[data.key] = action;
        window.dataLayer.push(info);
      } else {
        window.dataLayer.push({
          event: data.eventName,
        });
      }
    }
  } catch (ex) {
    console.log('Exception:', ex);
  }
}

const Onboarding = {
  login: {
    eventName: 'login', //tagname and eventname shoulb be identical
    key: 'user-details',
  }
}

const Onsearch = {
  search: {
    eventName: 'search',
    key: 'user-details',
  }
}

const OrderClick = {
  orders: {
    eventName: 'orderclick',
    key: 'user-details',
  }
}

const SearchStore = {
  searchStore: {
    eventName: 'searchStore',
    key: 'store-details',
  }
}

const StoreClicked = {
  storeClicked: {
    eventName: 'storeClicked',
    key: 'store-details',
  }
}

const OnUpdateDetails = {
  updateDetails: {
    eventName: 'updateDetails',
    key: 'store-details'
  }
}

const OnAddDetails = {
  addDetails: {
    eventName: 'addDetails',
    key: 'store-details'
  }
}

const OnDeleteDetails = {
  deleteDetails: {
    eventName: 'deleteDetails',
    key: 'store-details'
  }
}

export const Analytics = {
  logEvent,
  logEventWithVariable,
  Onboarding,
  Onsearch,
  OrderClick,
  SearchStore,
  StoreClicked,
  OnUpdateDetails,
  OnAddDetails,
  OnDeleteDetails
};
